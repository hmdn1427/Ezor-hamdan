"use strict";

/* =====================================================================
   1. SETTINGS  - things you may want to edit
   ===================================================================== */
const CONFIG = {
  currency: "Rs",
  promoMessage: "10% OFF on shopping up to Rs 3000/-",
  email: "ezor.officials@gmail.com",
  instagramUrl: "https://www.instagram.com/ezor_official",
  facebookUrl: "",                          // leave empty to hide the icon
};

const FILTERS = [
  { value: "all", label: "All" },
  { value: "perfume", label: "Perfume" },
  { value: "wallet", label: "Wallet" },
  { value: "belt", label: "Belt" },
  { value: "men", label: "Men's" },
  { value: "ladies", label: "Ladies" },
];

const PAGES = ["home", "about", "catalogue", "cart", "checkout", "reviews", "admin"];

// Simple drawings shown for products that have no photo yet.
const PLACEHOLDER_ART = {
  perfume: `<svg viewBox="0 0 100 100" fill="rgba(255,255,255,.35)" stroke="currentColor" stroke-width="2">
    <rect x="40" y="8" width="20" height="12" fill="#1b1720"/><rect x="44" y="20" width="12" height="10"/>
    <rect x="26" y="30" width="48" height="60" rx="12"/><rect x="34" y="48" width="32" height="30" fill="rgba(255,255,255,.8)" stroke-width="1"/></svg>`,
  wallet: `<svg viewBox="0 0 100 100" fill="rgba(255,255,255,.35)" stroke="currentColor" stroke-width="2">
    <rect x="14" y="28" width="72" height="48" rx="8"/><path d="M14 42h72M64 52h22v12H64z"/></svg>`,
  belt: `<svg viewBox="0 0 100 100" fill="rgba(255,255,255,.35)" stroke="currentColor" stroke-width="2">
    <rect x="6" y="42" width="88" height="16" rx="3"/><rect x="38" y="36" width="22" height="28" rx="4"/>
    <circle cx="78" cy="50" r="1.5"/><circle cx="70" cy="50" r="1.5"/></svg>`,
};

/* =====================================================================
   2. CART STORAGE  - the cart is kept in the visitor's browser
   ===================================================================== */
const memoryStore = {};

const storage = {
  get(key) {
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : null;
    } catch {
      return memoryStore[key] ?? null;
    }
  },
  set(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch {
      memoryStore[key] = value;
    }
  },
  clear() {
    try {
      localStorage.clear();
    } catch {
      /* storage is unavailable - nothing to clear */
    }
  },
};

/* =====================================================================
   3. STATE  - products, reviews and settings come from the server
   ===================================================================== */
const state = {
  products: [],
  reviews: [],
  cart: storage.get("cart") ?? {},          // { productId: quantity }
  whatsappNumber: "",
  filter: "all",
  editing: false,
  firstPageView: true,
};

/* =====================================================================
   4. HELPERS
   ===================================================================== */
const byId = (id) => document.getElementById(id);
const prefersReducedMotion = () => window.matchMedia("(prefers-reduced-motion: reduce)").matches;
const formatPrice = (amount) => `${CONFIG.currency} ${amount}`;

function escapeHtml(text) {
  const div = document.createElement("div");
  div.textContent = text;
  return div.innerHTML;
}

let toastTimer;
function showToast(message) {
  const toast = byId("toast");
  toast.textContent = message;
  toast.classList.add("visible");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("visible"), 2200);
}

/* =====================================================================
   5. SCROLL REVEAL  - boxes bounce up as they enter the screen
   ===================================================================== */
const revealObserver = "IntersectionObserver" in window
  ? new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        entry.target.classList.add("in");
        revealObserver.unobserve(entry.target);
      });
    }, { threshold: 0.06 })
  : null;

function registerRevealTargets() {
  document.querySelectorAll(".reveal:not(.tracked)").forEach((element) => {
    const position = Array.prototype.indexOf.call(element.parentNode.children, element);
    element.classList.add("tracked");
    element.style.setProperty("--delay", `${(position % 6) * 0.08}s`);
    if (revealObserver) revealObserver.observe(element);
    else element.classList.add("in");
  });
}

/* =====================================================================
   6. PAGE NAVIGATION  (hash based: #home, #catalogue, ...)
   ===================================================================== */
function currentPageName() {
  const name = window.location.hash.slice(1);
  return PAGES.includes(name) ? name : "home";
}

function activatePage() {
  const name = currentPageName();
  const nextPage = document.querySelector(`[data-page="${name}"]`);

  // Replay the entrance animation every time a page is opened.
  nextPage.querySelectorAll(".reveal").forEach((el) => el.classList.remove("in", "tracked"));
  document.querySelectorAll(".page").forEach((page) => page.classList.toggle("show", page === nextPage));
  document.querySelectorAll("#main-nav a").forEach((link) => {
    const isCurrent = link.hash === `#${name}` || (name === "checkout" && link.hash === "#cart");
    link.classList.toggle("active", isCurrent);
  });
  window.scrollTo(0, 0);
  registerRevealTargets();
}

function showPage() {
  const visiblePage = document.querySelector(".page.show");
  const shouldFade = visiblePage && !state.firstPageView && !prefersReducedMotion();
  state.firstPageView = false;

  if (!shouldFade) {
    activatePage();
    return;
  }
  visiblePage.classList.add("leaving");
  setTimeout(() => {
    visiblePage.classList.remove("leaving");
    activatePage();
  }, 220);
}

/* =====================================================================
   7. CATALOGUE
   ===================================================================== */
function matchesFilter(product, filter) {
  if (filter === "all") return true;
  if (product.category === filter || product.gender === filter) return true;
  return product.gender === "unisex" && (filter === "men" || filter === "ladies");
}

function productCardHtml(product) {
  const media = product.image
    ? `<img class="product-photo" src="${escapeHtml(product.image)}" alt="${escapeHtml(product.name)}" loading="lazy">`
    : PLACEHOLDER_ART[product.category];
  return `
    <article class="glass card reveal">
      ${media}
      <h3>${escapeHtml(product.name)}</h3>
      <p class="muted">${escapeHtml(product.note ?? "")}</p>
      <p class="price">${formatPrice(product.price)}</p>
      <button class="btn" data-action="add-to-cart" data-id="${product.id}">Add to cart</button>
    </article>`;
}

function renderCatalogue() {
  byId("filters").innerHTML = FILTERS.map(({ value, label }) =>
    `<button class="chip ${state.filter === value ? "active" : ""}" data-action="set-filter" data-filter="${value}">${label}</button>`
  ).join("");

  const matches = state.products.filter((product) => matchesFilter(product, state.filter));
  byId("catalogue-grid").innerHTML = matches.map(productCardHtml).join("")
    || "<p>Nothing here yet. Try another filter.</p>";
  registerRevealTargets();
}

function renderFeatured() {
  byId("featured").innerHTML = state.products.slice(0, 3).map(productCardHtml).join("");
  registerRevealTargets();
}

/* =====================================================================
   8. CART, CHECKOUT AND WHATSAPP
   ===================================================================== */
function cartLines() {
  return state.products
    .filter((product) => state.cart[product.id])
    .map((product) => ({ product, quantity: state.cart[product.id] }));
}

function cartTotal() {
  return cartLines().reduce((sum, { product, quantity }) => sum + product.price * quantity, 0);
}

function whatsappUrl(message) {
  return `https://wa.me/${state.whatsappNumber.replace(/\D/g, "")}?text=${encodeURIComponent(message)}`;
}

function updateWhatsappLinks() {
  const lines = cartLines();
  const orderMessage = lines.length
    ? `Hi Ezór, I'd like to order:\n${lines.map((l) => `${l.quantity} x ${l.product.name}`).join("\n")}\nTotal: ${formatPrice(cartTotal())}`
    : "Hi Ezór, I have a question.";
  const hasNumber = Boolean(state.whatsappNumber);

  byId("order-whatsapp").href = hasNumber ? whatsappUrl(orderMessage) : "#";
  byId("whatsapp-float").href = hasNumber ? whatsappUrl("Hi Ezór, I'd like to know more about your products.") : "#";
  byId("footer-whatsapp").href = byId("link-whatsapp").href = hasNumber ? whatsappUrl("Hi Ezór, I have a question.") : "#";
}

function renderCart() {
  const lines = cartLines();
  const itemCount = lines.reduce((sum, line) => sum + line.quantity, 0);

  byId("cart-list").innerHTML = lines.map(({ product, quantity }) => `
    <div class="row">
      <span>${escapeHtml(product.name)} <span class="muted">${formatPrice(product.price)}</span></span>
      <span class="quantity">
        <button aria-label="Remove one" data-action="change-quantity" data-id="${product.id}" data-delta="-1">-</button>
        ${quantity}
        <button aria-label="Add one" data-action="change-quantity" data-id="${product.id}" data-delta="1">+</button>
      </span>
    </div>`).join("") || "<p>Your cart is empty. Browse the catalogue to add something.</p>";

  byId("order-summary").innerHTML = lines.map(({ product, quantity }) => `
    <div class="row"><span>${quantity} x ${escapeHtml(product.name)}</span><span>${formatPrice(product.price * quantity)}</span></div>`
  ).join("") || "<p>No items yet.</p>";

  document.querySelectorAll("[data-total]").forEach((el) => { el.textContent = formatPrice(cartTotal()); });
  byId("cart-count").textContent = itemCount;
  updateWhatsappLinks();
}

function saveCart() {
  storage.set("cart", state.cart);
  renderCart();
}

function bumpCartCount() {
  const badge = byId("cart-count");
  badge.classList.remove("bump");
  void badge.offsetWidth;                   // restart the animation
  badge.classList.add("bump");
}

async function placeOrder() {
  const lines = cartLines();
  const customer = {
    name: byId("customer-name").value.trim(),
    email: byId("customer-email").value.trim(),
    phone: byId("customer-phone").value.trim(),
    address: byId("customer-address").value.trim(),
  };
  if (!lines.length) return showToast("Add an item before checking out");
  if (!customer.name || !customer.email || !customer.address) return showToast("Enter your name, email and address");

  try {
    const items = lines.map(({ product, quantity }) => ({ id: product.id, quantity }));
    const order = await api.createOrder(customer, items);
    state.cart = {};
    saveCart();
    showToast(`Order #${order.orderId} placed. Thank you!`);
    window.location.hash = "home";
  } catch (error) {
    showToast(error.message);
  }
}

/* =====================================================================
   9. REVIEWS
   ===================================================================== */
function renderReviews() {
  byId("reviews-list").innerHTML = state.reviews.map((review) => `
    <div class="glass card reveal">
      <div class="stars">${"★".repeat(review.stars)}${"☆".repeat(5 - review.stars)}</div>
      <p>${escapeHtml(review.text)}</p>
      <strong>${escapeHtml(review.name)}</strong>
    </div>`).join("");
  registerRevealTargets();
}

async function postReview() {
  const name = byId("review-name").value.trim();
  const text = byId("review-text").value.trim();
  if (!name || !text) return showToast("Add your name and a comment");

  try {
    await api.postReview({ name, stars: 5, text });
    state.reviews = await api.getReviews();
    byId("review-name").value = "";
    byId("review-text").value = "";
    renderReviews();
    showToast("Review posted");
  } catch (error) {
    showToast(error.message);
  }
}

/* =====================================================================
   10. ADMIN  - log in, then manage products, orders and the WhatsApp number
   ===================================================================== */
const ORDER_STATUSES = ["new", "packed", "delivered", "cancelled"];

function renderAdminProducts() {
  byId("admin-products").innerHTML = state.products.map((product) => `
    <div class="row">
      <span>${escapeHtml(product.name)} <span class="muted">${formatPrice(product.price)}</span></span>
      <button class="chip" data-action="delete-product" data-id="${product.id}">Delete</button>
    </div>`).join("");
}

async function renderAdminOrders() {
  const orders = await api.admin.listOrders();
  byId("admin-orders").innerHTML = orders.map((order) => `
    <div class="admin-order">
      <div class="row"><strong>#${order.id} ${escapeHtml(order.customer_name)}</strong><span>${formatPrice(order.total)}</span></div>
      <p class="muted">
        ${escapeHtml(order.phone)} ${escapeHtml(order.email)}<br>
        ${escapeHtml(order.address)}<br>
        ${order.items.map((item) => `${item.quantity} x ${escapeHtml(item.product_name)}`).join(", ")}
      </p>
      <select data-order-id="${order.id}" aria-label="Order status">
        ${ORDER_STATUSES.map((status) => `<option ${status === order.status ? "selected" : ""}>${status}</option>`).join("")}
      </select>
    </div>`).join("") || "<p>No orders yet.</p>";
}

async function reloadProducts() {
  state.products = await api.getProducts();
  renderFeatured();
  renderCatalogue();
  renderCart();
  renderAdminProducts();
}

async function openAdmin() {
  byId("admin-lock").hidden = true;
  byId("admin-panel").hidden = false;
  byId("admin-tools").hidden = false;
  byId("admin-whatsapp").value = state.whatsappNumber;
  renderAdminProducts();
  await renderAdminOrders();
}

async function loginAdmin() {
  try {
    await api.login(byId("admin-username").value.trim(), byId("admin-password").value);
    byId("admin-password").value = "";
    await openAdmin();
  } catch (error) {
    showToast(error.message);
  }
}

function logoutAdmin() {
  api.logout();
  window.location.reload();
}

async function saveWhatsappNumber() {
  try {
    const result = await api.admin.saveWhatsapp(byId("admin-whatsapp").value);
    state.whatsappNumber = result.whatsappNumber;
    applyContactDetails();
    updateWhatsappLinks();
    showToast("Number saved");
  } catch (error) {
    showToast(error.message);
  }
}

// Shrinks a photo so the page stays fast. Resolves to a JPEG data URL.
function resizeImage(file, maxSize = 600) {
  return new Promise((resolve) => {
    const reader = new FileReader();
    reader.onload = () => {
      const image = new Image();
      image.onload = () => {
        const scale = Math.min(1, maxSize / Math.max(image.width, image.height));
        const canvas = document.createElement("canvas");
        canvas.width = image.width * scale;
        canvas.height = image.height * scale;
        canvas.getContext("2d").drawImage(image, 0, 0, canvas.width, canvas.height);
        resolve(canvas.toDataURL("image/jpeg", 0.78));
      };
      image.src = reader.result;
    };
    reader.readAsDataURL(file);
  });
}

async function addProduct() {
  const name = byId("new-name").value.trim();
  const price = parseFloat(byId("new-price").value);
  if (!name || Number.isNaN(price)) return showToast("Enter a name and price");

  try {
    const photo = byId("new-photo").files[0];
    await api.admin.addProduct({
      name,
      category: byId("new-category").value,
      gender: byId("new-gender").value,
      price,
      note: byId("new-note").value.trim(),
      image: photo ? await resizeImage(photo) : "",
    });
    ["new-name", "new-price", "new-note", "new-photo"].forEach((id) => { byId(id).value = ""; });
    await reloadProducts();
    showToast("Product added");
  } catch (error) {
    showToast(error.message);
  }
}

async function deleteProduct(id) {
  try {
    await api.admin.deleteProduct(id);
    delete state.cart[id];
    saveCart();
    await reloadProducts();
  } catch (error) {
    showToast(error.message);
  }
}

/* =====================================================================
   11. TEXT EDIT MODE  - elements marked data-editable are saved on the server
   ===================================================================== */
async function toggleEditMode() {
  const editableElements = document.querySelectorAll("[data-editable]");
  state.editing = !state.editing;
  document.body.classList.toggle("editing", state.editing);
  byId("edit-button").textContent = state.editing ? "Done editing" : "Edit text";

  if (state.editing) {
    editableElements.forEach((element) => {
      element.dataset.before = element.textContent;       // remember the old text
      element.contentEditable = true;
    });
    return;
  }

  try {
    for (const element of editableElements) {
      element.contentEditable = false;
      if (element.textContent !== element.dataset.before) {
        await api.admin.saveText(element.dataset.editable, element.textContent.trim());
      }
    }
    showToast("Changes saved");
  } catch (error) {
    showToast(error.message);
  }
}

function applySavedTexts(texts) {
  document.querySelectorAll("[data-editable]").forEach((element) => {
    if (texts[element.dataset.editable] !== undefined) element.textContent = texts[element.dataset.editable];
  });
}

/* =====================================================================
   12. CLICK ACTIONS  - every button uses data-action="name"
   ===================================================================== */
const actions = {
  "reload-home": () => {
    window.location.hash = "#home";
    window.location.reload();
  },
  "shop-filter": (el) => { state.filter = el.dataset.filter; renderCatalogue(); },
  "set-filter": (el) => { state.filter = el.dataset.filter; renderCatalogue(); },
  "add-to-cart": (el) => {
    const id = Number(el.dataset.id);
    state.cart[id] = (state.cart[id] ?? 0) + 1;
    saveCart();
    bumpCartCount();
    showToast("Added to cart");
  },
  "change-quantity": (el) => {
    const id = Number(el.dataset.id);
    state.cart[id] = (state.cart[id] ?? 0) + Number(el.dataset.delta);
    if (state.cart[id] <= 0) delete state.cart[id];
    saveCart();
  },
  "place-order": placeOrder,
  "post-review": postReview,
  "login-admin": loginAdmin,
  "logout-admin": logoutAdmin,
  "save-whatsapp": saveWhatsappNumber,
  "add-product": addProduct,
  "delete-product": (el) => deleteProduct(Number(el.dataset.id)),
  "toggle-edit": toggleEditMode,
};

document.addEventListener("click", (event) => {
  // While editing text, links and buttons must not navigate away.
  if (state.editing && event.target.closest("[data-editable]")) event.preventDefault();

  // WhatsApp links need a number first.
  if (event.target.closest("[data-whatsapp]") && !state.whatsappNumber) {
    event.preventDefault();
    showToast("WhatsApp number not set yet");
    return;
  }

  const trigger = event.target.closest("[data-action]");
  if (!trigger) return;
  if (trigger.dataset.action === "reload-home") event.preventDefault();
  actions[trigger.dataset.action]?.(trigger);
});

// The order-status drop-down in the admin page saves as soon as it changes.
document.addEventListener("change", async (event) => {
  const select = event.target.closest("[data-order-id]");
  if (!select) return;
  try {
    await api.admin.setOrderStatus(select.dataset.orderId, select.value);
    showToast("Order updated");
  } catch (error) {
    showToast(error.message);
  }
});

/* =====================================================================
   13. START-UP
   ===================================================================== */
function renderPromo() {
  const item = `<span>${escapeHtml(CONFIG.promoMessage)}</span><span aria-hidden="true">✦</span>`;
  const set = (hidden) => `<div class="promo-set" ${hidden ? 'aria-hidden="true"' : ""}>${item.repeat(6)}</div>`;
  byId("promo").innerHTML = `<div class="promo-track">${set(false)}${set(true)}</div>`;
}

function applyContactDetails() {
  const email = byId("footer-email");
  email.href = `mailto:${CONFIG.email}`;
  email.textContent = CONFIG.email;
  byId("footer-whatsapp").textContent = state.whatsappNumber ? `WhatsApp: +${state.whatsappNumber}` : "WhatsApp";
  byId("link-instagram").href = CONFIG.instagramUrl;
  byId("link-facebook").hidden = !CONFIG.facebookUrl;
  byId("link-facebook").href = CONFIG.facebookUrl || "#";
  byId("year").textContent = new Date().getFullYear();
}

async function restoreAdminSession() {
  if (!api.isLoggedIn()) return;
  try {
    await openAdmin();
  } catch {
    api.logout();                           // the saved login has expired
  }
}

async function init() {
  renderPromo();
  try {
    const [site, products, reviews] = await Promise.all([api.getSite(), api.getProducts(), api.getReviews()]);
    state.whatsappNumber = site.whatsappNumber;
    state.products = products;
    state.reviews = reviews;
    applySavedTexts(site.texts);
  } catch {
    showToast("Could not reach the server");
  }

  applyContactDetails();
  renderFeatured();
  renderCatalogue();
  renderReviews();
  renderCart();
  window.addEventListener("hashchange", showPage);
  showPage();
  restoreAdminSession();
}

document.addEventListener("DOMContentLoaded", init);
