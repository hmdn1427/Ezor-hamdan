// Runs before the page is drawn: lets the CSS hide "reveal" boxes only while JavaScript is working.
document.documentElement.classList.add("js");
