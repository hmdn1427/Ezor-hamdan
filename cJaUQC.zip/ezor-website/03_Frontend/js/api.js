"use strict";

/* Everything the website says to the server goes through this file.
   Each function sends one request to the backend (see backend/server.py). */
const api = (() => {
  let adminToken = sessionStorage.getItem("adminToken") ?? "";

  async function request(method, path, body) {
    const headers = { "Content-Type": "application/json" };
    if (adminToken) headers.Authorization = `Bearer ${adminToken}`;

    const response = await fetch(`/api${path}`, {
      method,
      headers,
      body: body === undefined ? undefined : JSON.stringify(body),
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || "Something went wrong");
    return data;
  }

  return {
    // Public
    getSite: () => request("GET", "/site"),
    getProducts: () => request("GET", "/products"),
    getReviews: () => request("GET", "/reviews"),
    postReview: (review) => request("POST", "/reviews", review),
    createOrder: (customer, items) => request("POST", "/orders", { customer, items }),

    // Admin login
    async login(username, password) {
      const { token } = await request("POST", "/admin/login", { username, password });
      adminToken = token;
      sessionStorage.setItem("adminToken", token);
    },
    logout() {
      adminToken = "";
      sessionStorage.removeItem("adminToken");
    },
    isLoggedIn: () => Boolean(adminToken),

    // Admin only
    admin: {
      listOrders: () => request("GET", "/admin/orders"),
      setOrderStatus: (id, status) => request("PUT", `/admin/orders/${id}`, { status }),
      addProduct: (product) => request("POST", "/admin/products", product),
      deleteProduct: (id) => request("DELETE", `/admin/products/${id}`),
      saveWhatsapp: (number) => request("PUT", "/admin/whatsapp", { number }),
      saveText: (key, text) => request("PUT", "/admin/texts", { key, text }),
    },
  };
})();
