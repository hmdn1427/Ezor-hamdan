# Ezór: online perfume and leather-goods shop

A complete website with a front end, a back end and a database.
It needs only **Python 3.9+**. There is nothing to install.

## Quick start

```bash
cp .env.example .env        # then open .env and set ADMIN_PASSWORD
python3 app.py
```

Open http://127.0.0.1:8000. The admin page is http://127.0.0.1:8000/#admin.

`app.py` in the project root is the entry point. It starts the server in `04_Backend/`.

## Folder guide

| Folder / file | What it holds |
|---|---|
| `01_Project_Requirements/` | Website features, user roles and business requirements |
| `02_Design_Assets/` | Logo, product photos, icons, fonts notes, design tokens |
| `03_Frontend/` | The website pages: HTML, CSS and JavaScript |
| `04_Backend/` | Server code, API routes, security and login |
| `05_Database/` | Table definitions (migrations), sample data and the live database (`data/`, never committed) |
| `06_Documentation/` | API reference, setup, deployment and security guides |
| `07_Testing/` | Test cases, acceptance criteria and automated tests |
| `.env.example` | Template for settings and secrets (copy to `.env`) |
| `.gitignore` | Keeps secrets, the live database and customer uploads out of GitHub |
| `app.py` | Starts the website |

## Everyday tasks

- **Add products, change prices, see orders, change the WhatsApp number, edit page text:** log in at `/#admin`.
- **Run the tests:** `python3 -m unittest discover -s 07_Testing -v`
- **Put it online:** see `06_Documentation/DEPLOYMENT.md`.
- **Before going live:** follow the checklist in `06_Documentation/SECURITY.md`.

## Handoff notes

- Brand contact details (email, Instagram, Facebook) are in `03_Frontend/js/app.js`, section 1 `CONFIG`.
- Sample products and reviews are in `05_Database/seeds/sample_data.sql`. Prices are placeholders.
- Not built yet: online payments, order email alerts, the 10% offer in the cart, customer accounts.
