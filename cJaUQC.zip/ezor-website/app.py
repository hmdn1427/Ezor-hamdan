"""Starts the Ezór website.  Run:  python3 app.py

This file only points to the real server code in 04_Backend/, so GitHub hosts and
tools that look for app.py in the project root can find an entry point.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent / "04_Backend"))

from server import main  # noqa: E402  (import must come after the path is set)

if __name__ == "__main__":
    main()
