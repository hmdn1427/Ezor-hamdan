# Requirements

## Business goal
Sell Ezór eau de parfum, wallets and belts online, and take orders from customers in Pakistan.
Orders can also be started through WhatsApp.

## User roles
| Role | Can do |
|---|---|
| **Visitor / customer** | Browse the catalogue, filter by category and men's/ladies, add to cart, place an order, read and post reviews, contact the brand by WhatsApp or email |
| **Admin (shop owner)** | Everything above, plus: log in, add and delete products with photos, view orders and set their status, change the WhatsApp number, edit page text |

## Pages
Home, About us, Catalogue, Cart, Checkout, Reviews, and a hidden Admin page (`/#admin`).

## Functional requirements
1. Catalogue with filters: All, Perfume, Wallet, Belt, Men's, Ladies.
2. Cart that remembers items in the visitor's browser.
3. Checkout that saves the order and its customer details in the database.
4. Order totals are calculated on the server from current prices.
5. Reviews saved in the database and shown to everyone.
6. Admin login, product management, order management, WhatsApp number, text editing.
7. Sliding offer banner at the top of every page.
8. WhatsApp chat button on every page; footer with email, Instagram, Facebook and WhatsApp.
9. Clicking the Ezór logo refreshes the site and returns home.

## Non-functional requirements
- Works on phones, tablets and desktops (iOS, Android, Windows, macOS) with no sideways scrolling.
- Light and dark mode follow the device; animations are switched off for people who prefer reduced motion.
- Safe by default: see `06_Documentation/SECURITY.md`.
- No paid services or third-party Python packages required.

## Open decisions
- Exact rule for the "10% off on shopping up to Rs 3000" offer.
- Online payment methods (card, JazzCash, Easypaisa).
- Final prices, product descriptions and the Facebook page link.
