"""Automated tests for the Ezór backend.

Run from the project root:   python3 -m unittest discover -s 07_Testing -v
The tests use a temporary database, so your real data is never touched.
"""
import json
import os
import sys
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
from http.server import ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
TEMP = tempfile.mkdtemp()
os.environ.update(
    APP_ENV="development",
    ADMIN_USERNAME="admin",
    ADMIN_PASSWORD="test-password-123",
    DATABASE_PATH=f"{TEMP}/test.db",
    UPLOADS_DIR=f"{TEMP}/uploads",
    LOAD_SAMPLE_DATA="true",
)
sys.path.insert(0, str(ROOT / "04_Backend"))

import database  # noqa: E402
import server    # noqa: E402

TINY_PNG = (
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg=="
)
CUSTOMER = {"name": "Ali", "email": "ali@example.com", "phone": "0300", "address": "Lahore"}


class ApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        database.init_database()
        cls.httpd = ThreadingHTTPServer(("127.0.0.1", 0), server.Handler)
        cls.base = f"http://127.0.0.1:{cls.httpd.server_address[1]}"
        threading.Thread(target=cls.httpd.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.httpd.shutdown()

    def call(self, method, path, body=None, token=None):
        headers = {"Content-Type": "application/json"}
        if token:
            headers["Authorization"] = f"Bearer {token}"
        data = json.dumps(body).encode() if body is not None else None
        request = urllib.request.Request(self.base + path, data=data, method=method, headers=headers)
        try:
            with urllib.request.urlopen(request) as response:
                return response.status, self.parse(response.read()), response.headers
        except urllib.error.HTTPError as error:
            return error.code, self.parse(error.read()), error.headers

    @staticmethod
    def parse(raw):
        """JSON for API answers; an empty dict for web pages and images."""
        try:
            return json.loads(raw or b"{}")
        except ValueError:
            return {}

    def login(self):
        status, data, _ = self.call("POST", "/api/admin/login", {"username": "admin", "password": "test-password-123"})
        self.assertEqual(status, 200)
        return data["token"]

    # ---- public pages and data
    def test_01_products_and_site(self):
        status, products, _ = self.call("GET", "/api/products")
        self.assertEqual(status, 200)
        self.assertGreaterEqual(len(products), 9)
        status, site, _ = self.call("GET", "/api/site")
        self.assertEqual(site["whatsappNumber"], "923422950550")

    def test_02_home_page_has_security_headers(self):
        status, _, headers = self.call("GET", "/")
        self.assertEqual(status, 200)
        self.assertIn("script-src 'self'", headers["Content-Security-Policy"])
        self.assertEqual(headers["X-Frame-Options"], "DENY")
        self.assertEqual(headers["X-Content-Type-Options"], "nosniff")

    def test_03_files_outside_the_site_are_blocked(self):
        for path in ["/../04_Backend/server.py", "/%2e%2e/.env", "/.env", "/images/../../.env", "/05_Database/data/ezor.db"]:
            self.assertEqual(self.call("GET", path)[0], 404, path)

    # ---- orders
    def test_10_order_total_is_calculated_by_the_server(self):
        _, products, _ = self.call("GET", "/api/products")
        price = products[0]["price"]
        body = {"customer": CUSTOMER, "items": [{"id": products[0]["id"], "quantity": 2, "price": 1}]}
        status, order, _ = self.call("POST", "/api/orders", body)
        self.assertEqual(status, 200)
        self.assertEqual(order["total"], price * 2)          # the "price": 1 sent by the browser is ignored

    def test_11_bad_orders_are_rejected(self):
        self.assertEqual(self.call("POST", "/api/orders", {"customer": CUSTOMER, "items": []})[0], 400)
        self.assertEqual(self.call("POST", "/api/orders", {"customer": {**CUSTOMER, "email": "nope"}, "items": [{"id": 1, "quantity": 1}]})[0], 400)
        self.assertEqual(self.call("POST", "/api/orders", {"customer": CUSTOMER, "items": [{"id": 99999, "quantity": 1}]})[0], 400)
        self.assertEqual(self.call("POST", "/api/orders", {"customer": CUSTOMER, "items": [{"id": 1, "quantity": 0}]})[0], 400)

    # ---- admin
    def test_20_admin_routes_need_a_login(self):
        self.assertEqual(self.call("GET", "/api/admin/orders")[0], 401)
        self.assertEqual(self.call("POST", "/api/admin/products", {"name": "X"})[0], 401)
        self.assertEqual(self.call("GET", "/api/admin/orders", token="made-up-token")[0], 401)

    def test_21_admin_can_manage_products_and_orders(self):
        token = self.login()
        status, orders, _ = self.call("GET", "/api/admin/orders", token=token)
        self.assertEqual(status, 200)
        self.assertEqual(self.call("PUT", f"/api/admin/orders/{orders[0]['id']}", {"status": "packed"}, token)[0], 200)
        self.assertEqual(self.call("PUT", f"/api/admin/orders/{orders[0]['id']}", {"status": "bogus"}, token)[0], 400)

        product = {"name": "Test Belt", "category": "belt", "gender": "men", "price": 750, "note": "x", "image": TINY_PNG}
        status, created, _ = self.call("POST", "/api/admin/products", product, token)
        self.assertEqual(status, 200)
        self.assertEqual(self.call("DELETE", f"/api/admin/products/{created['id']}", None, token)[0], 200)

    def test_22_fake_photos_are_rejected(self):
        token = self.login()
        fake = "data:image/png;base64,SGVsbG8gdGhpcyBpcyBub3QgYW4gaW1hZ2U="       # plain text, not a picture
        product = {"name": "Bad", "category": "belt", "gender": "men", "price": 1, "image": fake}
        self.assertEqual(self.call("POST", "/api/admin/products", product, token)[0], 400)

    def test_23_edited_text_is_saved(self):
        token = self.login()
        self.assertEqual(self.call("PUT", "/api/admin/texts", {"key": "hero-title", "text": "Hello"}, token)[0], 200)
        self.assertEqual(self.call("GET", "/api/site")[1]["texts"]["hero-title"], "Hello")
        self.assertEqual(self.call("PUT", "/api/admin/texts", {"key": "../bad key", "text": "x"}, token)[0], 400)

    # ---- last: this uses up the login attempts
    def test_99_too_many_login_attempts_are_blocked(self):
        codes = [self.call("POST", "/api/admin/login", {"username": "admin", "password": "wrong"})[0] for _ in range(7)]
        self.assertIn(429, codes)


if __name__ == "__main__":
    unittest.main()
