# Test cases and acceptance criteria

Automated tests (`test_api.py`) cover the **API** items. Check the **Manual** items in a browser.

| # | Area | Check | Expected | Type |
|---|---|---|---|---|
| 1 | Catalogue | Open Catalogue, tap each filter | Only matching products show; Men's/Ladies include unisex | Manual |
| 2 | Cart | Add an item, change quantity, reload the page | Cart count and totals stay correct | Manual |
| 3 | Orders | Place an order with a fake price in the request | Total uses the database price | API |
| 4 | Orders | Empty cart, bad email, unknown product, quantity 0 | Rejected with an error message | API |
| 5 | Checkout | Place an order from the website | "Order #n placed", cart empties, order appears in admin | Manual |
| 6 | Reviews | Post a review | It shows for all visitors after reload | Manual |
| 7 | Admin | Open admin routes without logging in | `401` | API |
| 8 | Admin | Wrong password more than 5 times | `429` lock | API |
| 9 | Admin | Add a product with a photo, then delete it | Appears in catalogue, then disappears | API / Manual |
| 10 | Admin | Upload a text file renamed as a picture | Rejected | API |
| 11 | Admin | Edit page text, reload | New text stays for everyone | API / Manual |
| 12 | Security | Request `/.env`, `/../04_Backend/server.py` | `404` | API |
| 13 | Security | Check response headers | CSP, X-Frame-Options, nosniff present | API |
| 14 | Responsive | Open at 320, 390, 768, 1280 and 1920 px wide | No sideways scrolling; nothing overlaps | Manual |
| 15 | Navigation | Tap the Ezór logo | Page reloads on Home | Manual |
| 16 | Contact | Tap email, Instagram, WhatsApp | Mail app, Instagram profile, WhatsApp chat open | Manual |
| 17 | Motion | Turn on "reduce motion" in the device | Animations stop; content still visible | Manual |

## Acceptance criteria
The release is accepted when all automated tests pass (`python3 -m unittest discover -s 07_Testing -v`),
all manual checks above pass on one iPhone and one Android phone, and the pre-launch list in
`06_Documentation/SECURITY.md` is complete.
