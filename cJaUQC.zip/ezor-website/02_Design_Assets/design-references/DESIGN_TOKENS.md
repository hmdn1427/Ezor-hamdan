# Design references

## Look and feel
Quiet luxury: frosted-glass panels over a slowly moving pastel gradient (lilac, blush, gold),
with a black Ezór wordmark at the top centre.

## Typography
- Headings: **Cormorant Garamond** (serif, italic for the main headline)
- Body and buttons: **Jost** (clean sans-serif)
- Both load from Google Fonts. To host them yourself, download the files into `../fonts/`
  and add `@font-face` rules in `03_Frontend/css/style.css`.

## Colours (light mode)
| Name | Value |
|---|---|
| Ink (text) | `#1b1720` |
| Muted text | `#5d5566` |
| Accent | `#6b4a7a` |
| Gradient | `#f4eef0`, `#d9c6d6`, `#f0d9b5`, `#c9b8e8` |
| Button gradient | `#7a5a8c` to `#c58b8b` |
| WhatsApp green | `#1fa855` to `#5be38b` |

All colours are defined once at the top of `03_Frontend/css/style.css` (section 1, design tokens).

## Assets in this folder
- `logo/logo.png`: transparent Ezór wordmark (turns white in dark mode).
- `images/`: hero photo and Ezór Prime product photos (resized for the web).
- `icons/`: WhatsApp, Instagram and Facebook icons as SVG.
