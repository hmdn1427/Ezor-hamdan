Fonts are loaded from Google Fonts (Cormorant Garamond and Jost).
Put self-hosted font files here if you want the site to work without Google.
