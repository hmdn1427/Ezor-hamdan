-- Ezór database schema (SQLite). Created automatically on first start.

CREATE TABLE IF NOT EXISTS products (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT    NOT NULL,
    category    TEXT    NOT NULL CHECK (category IN ('perfume', 'wallet', 'belt')),
    gender      TEXT    NOT NULL CHECK (gender IN ('men', 'ladies', 'unisex')),
    price       INTEGER NOT NULL CHECK (price >= 0),          -- whole rupees
    note        TEXT    NOT NULL DEFAULT '',
    image       TEXT    NOT NULL DEFAULT '',                  -- web path, e.g. /uploads/ab12.jpg
    created_at  TEXT    NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS orders (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_name  TEXT    NOT NULL,
    email          TEXT    NOT NULL,
    phone          TEXT    NOT NULL DEFAULT '',
    address        TEXT    NOT NULL,
    total          INTEGER NOT NULL,                          -- calculated by the server
    status         TEXT    NOT NULL DEFAULT 'new' CHECK (status IN ('new', 'packed', 'delivered', 'cancelled')),
    created_at     TEXT    NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Each line keeps the name and price at the time of purchase, so old orders never change.
CREATE TABLE IF NOT EXISTS order_items (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id      INTEGER NOT NULL REFERENCES orders (id) ON DELETE CASCADE,
    product_id    INTEGER,
    product_name  TEXT    NOT NULL,
    unit_price    INTEGER NOT NULL,
    quantity      INTEGER NOT NULL CHECK (quantity > 0)
);

CREATE TABLE IF NOT EXISTS reviews (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT    NOT NULL,
    stars       INTEGER NOT NULL CHECK (stars BETWEEN 1 AND 5),
    text        TEXT    NOT NULL,
    created_at  TEXT    NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Site-wide values: 'whatsapp_number' and edited page texts ('text:hero-title', ...).
CREATE TABLE IF NOT EXISTS settings (
    key    TEXT PRIMARY KEY,
    value  TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS admins (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    username       TEXT NOT NULL UNIQUE,
    password_hash  TEXT NOT NULL,
    salt           TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_order_items_order ON order_items (order_id);
