# Database

SQLite, stored in one file: `data/ezor.db` (created on first start, never committed to GitHub).

| Folder | Purpose |
|---|---|
| `migrations/` | Numbered `.sql` files that build the tables. Applied in order, once each, and recorded in the `schema_migrations` table |
| `seeds/` | `sample_data.sql`: starter products and reviews (loaded once when there are no products; switch off with `LOAD_SAMPLE_DATA=false`) |
| `data/` | The live database and uploaded photos |

## Tables
```
products ──< order_items >── orders        reviews       settings       admins
```
- **products**: name, category, gender, price (whole rupees), note, image path
- **orders**: customer details, server-calculated total, status (new, packed, delivered, cancelled)
- **order_items**: each line keeps the product name and price at purchase time
- **reviews**: name, 1 to 5 stars, text
- **settings**: `whatsapp_number` and edited page texts (`text:<id>`)
- **admins**: username and a salted PBKDF2 password hash (never the password)

## Changing the structure later
Add a new file such as `migrations/002_add_discount_codes.sql`. Never edit a migration that has
already been used. It is applied automatically the next time the server starts.

## Backup
Stop the server (or copy while quiet) and copy the whole `data/` folder.
