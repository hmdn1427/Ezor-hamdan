-- Sample data for development and demos. Loaded once, when the products table is empty.
-- Prices are placeholders (whole rupees). Replace them from the admin page.

INSERT INTO products (name, category, gender, price, note, image) VALUES
    ('Ezór Prime',         'perfume', 'unisex', 2499, '30 ml eau de parfum',        '/images/prime-30ml.jpg'),
    ('Ezór Prime 100 ml',  'perfume', 'unisex', 5499, '100 ml eau de parfum',       '/images/prime-100ml.jpg'),
    ('Prime Sample Cards', 'perfume', 'unisex',  999, 'Four travel-size sprays',    '/images/sample-cards.jpg'),
    ('Ezór Noir',          'perfume', 'men',    2799, 'Wood, pepper, leather',      ''),
    ('Ezór Rosé',          'perfume', 'ladies', 2799, 'Rose, musk, amber',          ''),
    ('Slim Wallet',        'wallet',  'men',    1499, 'Full-grain leather',         ''),
    ('Clutch Wallet',      'wallet',  'ladies', 1799, 'Zip clutch, six card slots', ''),
    ('Classic Belt',       'belt',    'men',    1299, '35 mm, brushed buckle',      ''),
    ('Slim Belt',          'belt',    'ladies', 1199, '20 mm, gold buckle',         '');

INSERT INTO reviews (name, stars, text) VALUES
    ('Amara',  5, 'Prime lasts all day and never feels loud.'),
    ('Daniel', 5, 'The wallet is thin and the leather feels great.'),
    ('Sofia',  4, 'Beautiful bottle. I would love a bigger size.');

INSERT OR IGNORE INTO settings (key, value) VALUES ('whatsapp_number', '923422950550');
