"""Ezór web server: a small JSON API plus the website files (standard library only).

Run it with:  python3 backend/server.py
"""
import base64
import binascii
import json
import mimetypes
import re
import secrets
import time
import traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse

import config
import database
import security

CATEGORIES = ("perfume", "wallet", "belt")
GENDERS = ("men", "ladies", "unisex")
ORDER_STATUSES = ("new", "packed", "delivered", "cancelled")
IMAGE_PATTERN = re.compile(r"^data:image/(?:jpeg|png|webp);base64,(.+)$", re.DOTALL)
EMAIL_PATTERN = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
TEXT_KEY_PATTERN = re.compile(r"^[a-z0-9-]{1,40}$")

sessions = security.SessionStore()
rate_limiter = security.RateLimiter()


class ApiError(Exception):
    """An error that is sent back to the browser with a status code and message."""

    def __init__(self, status, message):
        super().__init__(message)
        self.status = status
        self.message = message


# ------------------------------------------------------------------ input checks
def text_field(data, name, max_length, required=True):
    value = str(data.get(name, "")).strip()
    if required and not value:
        raise ApiError(400, f"{name} is required")
    if len(value) > max_length:
        raise ApiError(400, f"{name} is too long")
    return value


def number_field(data, name, minimum, maximum):
    try:
        value = int(round(float(data.get(name))))
    except (TypeError, ValueError):
        raise ApiError(400, f"{name} must be a number")
    if not minimum <= value <= maximum:
        raise ApiError(400, f"{name} must be between {minimum} and {maximum}")
    return value


def choice_field(data, name, allowed):
    value = str(data.get(name, ""))
    if value not in allowed:
        raise ApiError(400, f"{name} must be one of: {', '.join(allowed)}")
    return value


# ------------------------------------------------------------------ uploaded photos
def save_uploaded_image(data_url):
    """Save a photo sent as a data URL and return its web path ('' when there is none)."""
    if not data_url:
        return ""
    match = IMAGE_PATTERN.match(data_url)
    if not match:
        raise ApiError(400, "Photo must be a JPEG, PNG or WebP image")
    try:
        raw_bytes = base64.b64decode(match.group(1), validate=True)
    except binascii.Error:
        raise ApiError(400, "Photo could not be read")
    if len(raw_bytes) > config.MAX_IMAGE_BYTES:
        raise ApiError(400, "Photo is too large (2 MB maximum)")
    image_type = security.detect_image_type(raw_bytes)
    if image_type is None:
        raise ApiError(400, "Photo must be a real JPEG, PNG or WebP image")

    config.UPLOADS_DIR.mkdir(parents=True, exist_ok=True)
    file_name = f"{secrets.token_hex(8)}.{image_type}"
    (config.UPLOADS_DIR / file_name).write_bytes(raw_bytes)
    return f"/uploads/{file_name}"


def remove_uploaded_image(web_path):
    if web_path.startswith("/uploads/"):
        (config.UPLOADS_DIR / web_path.rsplit("/", 1)[-1]).unlink(missing_ok=True)


# ------------------------------------------------------------------ routes
ROUTES = []


def route(method, pattern, admin_only=False, limit=None):
    """Register a function as the handler for a URL.

    limit=(count, seconds) allows each visitor that many requests per time window.
    """
    def register(handler):
        ROUTES.append((method, re.compile(f"^{pattern}$"), handler, admin_only, limit))
        return handler
    return register


# Public: what the website needs to display itself.
@route("GET", "/api/site")
def get_site(params, body):
    settings = database.get_settings()
    texts = {key[5:]: value for key, value in settings.items() if key.startswith("text:")}
    return {"whatsappNumber": settings.get("whatsapp_number", ""), "texts": texts}


@route("GET", "/api/products")
def get_products(params, body):
    return database.list_products()


@route("GET", "/api/reviews")
def get_reviews(params, body):
    return database.list_reviews()


@route("POST", "/api/reviews", limit=(5, 3600))
def post_review(params, body):
    database.create_review(text_field(body, "name", 60), number_field(body, "stars", 1, 5), text_field(body, "text", 500))
    return {"ok": True}


@route("POST", "/api/orders", limit=(15, 3600))
def post_order(params, body):
    customer_data = body.get("customer") or {}
    customer = {
        "name": text_field(customer_data, "name", 80),
        "email": text_field(customer_data, "email", 120),
        "phone": text_field(customer_data, "phone", 30, required=False),
        "address": text_field(customer_data, "address", 300),
    }
    if not EMAIL_PATTERN.match(customer["email"]):
        raise ApiError(400, "Enter a valid email address")

    raw_items = body.get("items")
    if not isinstance(raw_items, list) or not 0 < len(raw_items) <= 50:
        raise ApiError(400, "Your cart is empty")
    items = [{"id": number_field(item, "id", 1, 10**9), "quantity": number_field(item, "quantity", 1, 20)} for item in raw_items]
    return database.create_order(customer, items)


# Admin: login, then manage orders, products and site settings.
@route("POST", "/api/admin/login", limit=(5, 900))
def admin_login(params, body):
    if not database.check_admin_login(str(body.get("username", "")), str(body.get("password", ""))):
        time.sleep(0.5)                              # slows down password guessing
        raise ApiError(401, "Wrong username or password")
    return {"token": sessions.create()}


@route("GET", "/api/admin/orders", admin_only=True)
def admin_orders(params, body):
    return database.list_orders()


@route("PUT", r"/api/admin/orders/(\d+)", admin_only=True)
def admin_set_order_status(params, body):
    database.set_order_status(int(params[0]), choice_field(body, "status", ORDER_STATUSES))
    return {"ok": True}


@route("POST", "/api/admin/products", admin_only=True)
def admin_add_product(params, body):
    product_id = database.create_product(
        text_field(body, "name", 80),
        choice_field(body, "category", CATEGORIES),
        choice_field(body, "gender", GENDERS),
        number_field(body, "price", 0, 10_000_000),
        text_field(body, "note", 200, required=False),
        save_uploaded_image(body.get("image", "")),
    )
    return {"id": product_id}


@route("DELETE", r"/api/admin/products/(\d+)", admin_only=True)
def admin_delete_product(params, body):
    remove_uploaded_image(database.delete_product(int(params[0])))
    return {"ok": True}


@route("PUT", "/api/admin/whatsapp", admin_only=True)
def admin_set_whatsapp(params, body):
    number = re.sub(r"\D", "", str(body.get("number", "")))
    database.set_setting("whatsapp_number", number)
    return {"whatsappNumber": number}


@route("PUT", "/api/admin/texts", admin_only=True)
def admin_set_text(params, body):
    key = str(body.get("key", ""))
    if not TEXT_KEY_PATTERN.match(key):
        raise ApiError(400, "Invalid text key")
    database.set_setting(f"text:{key}", text_field(body, "text", 2000))
    return {"ok": True}


# ------------------------------------------------------------------ HTTP handling
class Handler(BaseHTTPRequestHandler):
    server_version = "EzorServer"

    def do_GET(self):
        self.dispatch("GET")

    def do_POST(self):
        self.dispatch("POST")

    def do_PUT(self):
        self.dispatch("PUT")

    def do_DELETE(self):
        self.dispatch("DELETE")

    def dispatch(self, method):
        path = urlparse(self.path).path
        if path.startswith("/api/"):
            self.handle_api(method, path)
        elif method == "GET":
            self.serve_file(path)
        else:
            self.send_json(405, {"error": "Method not allowed"})

    def client_ip(self):
        if config.TRUST_PROXY and self.headers.get("X-Forwarded-For"):
            return self.headers["X-Forwarded-For"].split(",")[0].strip()
        return self.client_address[0]

    def handle_api(self, method, path):
        try:
            for route_method, pattern, handler, admin_only, limit in ROUTES:
                match = pattern.match(path)
                if not match or route_method != method:
                    continue
                if admin_only:
                    self.require_admin()
                if limit and not rate_limiter.allow((path, self.client_ip()), *limit):
                    raise ApiError(429, "Too many requests. Please try again later.")
                return self.send_json(200, handler(match.groups(), self.read_json_body()))
            raise ApiError(404, "Not found")
        except ApiError as error:
            self.send_json(error.status, {"error": error.message})
        except ValueError as error:                  # raised by the database layer
            self.send_json(400, {"error": str(error)})
        except Exception:
            traceback.print_exc()
            self.send_json(500, {"error": "Server error"})

    def require_admin(self):
        token = self.headers.get("Authorization", "").removeprefix("Bearer ").strip()
        if not sessions.is_valid(token):
            raise ApiError(401, "Please log in again")

    def read_json_body(self):
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            raise ApiError(400, "Invalid request")
        if length > config.MAX_BODY_BYTES:
            raise ApiError(413, "Request is too large")
        if length == 0:
            return {}
        try:
            body = json.loads(self.rfile.read(length))
        except json.JSONDecodeError:
            raise ApiError(400, "Invalid JSON")
        if not isinstance(body, dict):
            raise ApiError(400, "Invalid JSON")
        return body

    def end_headers_with_security(self):
        for name, value in security.security_headers().items():
            self.send_header(name, value)
        self.end_headers()

    def send_json(self, status, data):
        payload = json.dumps(data).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(payload)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers_with_security()
        self.wfile.write(payload)

    def locate_file(self, path):
        """Map a URL to a folder and file name. Photos and logo live in 02_Design_Assets."""
        folders = {
            "/uploads/": config.UPLOADS_DIR,
            "/images/": config.ASSETS_DIR / "images",
            "/logo/": config.ASSETS_DIR / "logo",
        }
        for prefix, folder in folders.items():
            if path.startswith(prefix):
                return folder, path[len(prefix):]
        return config.FRONTEND_DIR, path.lstrip("/") or "index.html"

    def serve_file(self, path):
        root, relative = self.locate_file(path)
        file_path = (root / relative).resolve()
        hidden = any(part.startswith(".") for part in relative.split("/"))
        if hidden or root.resolve() not in file_path.parents or not file_path.is_file():
            return self.send_json(404, {"error": "Not found"})

        content = file_path.read_bytes()
        is_media = file_path.suffix.lower() in (".jpg", ".png", ".webp", ".svg")
        self.send_response(200)
        self.send_header("Content-Type", mimetypes.guess_type(file_path.name)[0] or "application/octet-stream")
        self.send_header("Content-Length", str(len(content)))
        self.send_header("Cache-Control", "public, max-age=86400" if is_media else "no-cache")
        self.end_headers_with_security()
        self.wfile.write(content)

    def log_message(self, format, *args):
        print(f"{self.client_ip()} - {format % args}")


def main():
    problems = config.problems()
    if problems:
        print("Cannot start the server:")
        for problem in problems:
            print(f"  - {problem}")
        raise SystemExit(1)

    database.init_database()
    Handler.server_version = "Ezor"
    Handler.sys_version = ""
    server = ThreadingHTTPServer((config.HOST, config.PORT), Handler)
    print(f"Ezór ({config.APP_ENV}) is running at http://{config.HOST}:{config.PORT}   (admin page: /#admin)")
    server.serve_forever()


if __name__ == "__main__":
    main()
