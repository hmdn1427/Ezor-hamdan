"""Settings, read from environment variables or from a .env file in the project root.

Copy .env.example to .env and fill it in. Real environment variables always win over .env.
"""
import os
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parent.parent


def _load_env_file(path):
    """Read KEY=value lines from a .env file (no extra packages needed)."""
    if not path.is_file():
        return
    for line in path.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


_load_env_file(ROOT_DIR / ".env")


def _flag(name, default):
    return os.environ.get(name, default).strip().lower() in ("1", "true", "yes")


# ---- Environment
APP_ENV = os.environ.get("APP_ENV", "development")      # "development" or "production"
IS_PRODUCTION = APP_ENV == "production"
HOST = os.environ.get("HOST", "127.0.0.1")              # use 0.0.0.0 on a hosting service
PORT = int(os.environ.get("PORT", "8000"))
TRUST_PROXY = _flag("TRUST_PROXY", "false")             # true only when behind your own proxy

# ---- Folders
FRONTEND_DIR = ROOT_DIR / "03_Frontend"
ASSETS_DIR = ROOT_DIR / "02_Design_Assets"
DATABASE_DIR = ROOT_DIR / "05_Database"
DATABASE_PATH = Path(os.environ.get("DATABASE_PATH", DATABASE_DIR / "data" / "ezor.db"))
UPLOADS_DIR = Path(os.environ.get("UPLOADS_DIR", DATABASE_DIR / "data" / "uploads"))
LOAD_SAMPLE_DATA = _flag("LOAD_SAMPLE_DATA", "true")

# ---- Admin login (the password is set from this value every time the server starts)
ADMIN_USERNAME = os.environ.get("ADMIN_USERNAME", "admin")
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "")
SESSION_HOURS = 4

# ---- Limits
MAX_BODY_BYTES = 6 * 1024 * 1024                        # largest request accepted
MAX_IMAGE_BYTES = 2 * 1024 * 1024                       # largest product photo accepted


def problems():
    """Return a list of settings that must be fixed before the server starts."""
    found = []
    minimum = 12 if IS_PRODUCTION else 8
    if len(ADMIN_PASSWORD) < minimum:
        found.append(f"ADMIN_PASSWORD must be set and at least {minimum} characters (see .env.example).")
    if IS_PRODUCTION and ADMIN_PASSWORD.lower() in ("change-me", "ezor2026", "password"):
        found.append("ADMIN_PASSWORD is a common password. Choose a different one.")
    return found
