"""All database access for Ezór (SQLite, standard library only)."""
import hashlib
import hmac
import os
import secrets
import sqlite3
from contextlib import contextmanager

import config

MIGRATIONS_DIR = config.DATABASE_DIR / "migrations"
SAMPLE_DATA_PATH = config.DATABASE_DIR / "seeds" / "sample_data.sql"


@contextmanager
def db():
    """Open a connection, save on success, undo on error, always close."""
    connection = sqlite3.connect(config.DATABASE_PATH)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    try:
        yield connection
        connection.commit()
    except Exception:
        connection.rollback()
        raise
    finally:
        connection.close()


def all_rows(cursor):
    return [dict(row) for row in cursor.fetchall()]


# ---------------------------------------------------------------- start-up
def hash_password(password, salt):
    return hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt), 200_000).hex()


def apply_migrations(conn):
    """Run every .sql file in 05_Database/migrations that has not been applied yet."""
    conn.execute(
        "CREATE TABLE IF NOT EXISTS schema_migrations "
        "(name TEXT PRIMARY KEY, applied_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)"
    )
    applied = {row["name"] for row in conn.execute("SELECT name FROM schema_migrations")}
    for path in sorted(MIGRATIONS_DIR.glob("*.sql")):
        if path.name not in applied:
            conn.executescript(path.read_text())
            conn.execute("INSERT INTO schema_migrations (name) VALUES (?)", (path.name,))


def init_database():
    """Create the tables, add sample data the first time, and set the admin login."""
    config.DATABASE_PATH.parent.mkdir(parents=True, exist_ok=True)
    with db() as conn:
        apply_migrations(conn)

        if config.LOAD_SAMPLE_DATA and conn.execute("SELECT COUNT(*) FROM products").fetchone()[0] == 0:
            conn.executescript(SAMPLE_DATA_PATH.read_text())

        salt = secrets.token_hex(16)
        conn.execute(
            """INSERT INTO admins (username, password_hash, salt) VALUES (?, ?, ?)
               ON CONFLICT (username) DO UPDATE SET password_hash = excluded.password_hash, salt = excluded.salt""",
            (config.ADMIN_USERNAME, hash_password(config.ADMIN_PASSWORD, salt), salt),
        )
    try:
        os.chmod(config.DATABASE_PATH, 0o600)               # only the server's user can read it
    except OSError:
        pass


def check_admin_login(username, password):
    with db() as conn:
        admin = conn.execute("SELECT password_hash, salt FROM admins WHERE username = ?", (username,)).fetchone()
    if admin is None:
        return False
    return hmac.compare_digest(admin["password_hash"], hash_password(password, admin["salt"]))


# ---------------------------------------------------------------- products
def list_products():
    with db() as conn:
        return all_rows(conn.execute("SELECT * FROM products ORDER BY id"))


def create_product(name, category, gender, price, note, image):
    with db() as conn:
        cursor = conn.execute(
            "INSERT INTO products (name, category, gender, price, note, image) VALUES (?, ?, ?, ?, ?, ?)",
            (name, category, gender, price, note, image),
        )
        return cursor.lastrowid


def delete_product(product_id):
    """Delete a product and return its image path (so the file can be removed)."""
    with db() as conn:
        row = conn.execute("SELECT image FROM products WHERE id = ?", (product_id,)).fetchone()
        conn.execute("DELETE FROM products WHERE id = ?", (product_id,))
    return row["image"] if row else ""


# ---------------------------------------------------------------- reviews
def list_reviews():
    with db() as conn:
        return all_rows(conn.execute("SELECT name, stars, text FROM reviews ORDER BY id DESC"))


def create_review(name, stars, text):
    with db() as conn:
        conn.execute("INSERT INTO reviews (name, stars, text) VALUES (?, ?, ?)", (name, stars, text))


# ---------------------------------------------------------------- settings
def get_settings():
    with db() as conn:
        return {row["key"]: row["value"] for row in conn.execute("SELECT key, value FROM settings")}


def set_setting(key, value):
    with db() as conn:
        conn.execute(
            "INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT (key) DO UPDATE SET value = excluded.value",
            (key, value),
        )


# ---------------------------------------------------------------- orders
def create_order(customer, items):
    """Save an order. Prices come from the database, never from the browser."""
    with db() as conn:
        lines, total = [], 0
        for item in items:
            product = conn.execute("SELECT id, name, price FROM products WHERE id = ?", (item["id"],)).fetchone()
            if product is None:
                raise ValueError("One of the products is no longer available")
            total += product["price"] * item["quantity"]
            lines.append((product, item["quantity"]))

        order_id = conn.execute(
            "INSERT INTO orders (customer_name, email, phone, address, total) VALUES (?, ?, ?, ?, ?)",
            (customer["name"], customer["email"], customer["phone"], customer["address"], total),
        ).lastrowid
        conn.executemany(
            "INSERT INTO order_items (order_id, product_id, product_name, unit_price, quantity) VALUES (?, ?, ?, ?, ?)",
            [(order_id, p["id"], p["name"], p["price"], quantity) for p, quantity in lines],
        )
    return {"orderId": order_id, "total": total}


def list_orders():
    with db() as conn:
        orders = all_rows(conn.execute("SELECT * FROM orders ORDER BY id DESC"))
        items = all_rows(conn.execute("SELECT order_id, product_name, unit_price, quantity FROM order_items"))
    for order in orders:
        order["items"] = [item for item in items if item["order_id"] == order["id"]]
    return orders


def set_order_status(order_id, status):
    with db() as conn:
        conn.execute("UPDATE orders SET status = ? WHERE id = ?", (status, order_id))
