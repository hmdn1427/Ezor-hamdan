"""Security helpers: rate limiting, admin sessions, photo checks and response headers."""
import secrets
import threading
import time
from collections import defaultdict, deque

import config


class RateLimiter:
    """Allows at most `limit` requests per `window_seconds` for each key (for example, an IP)."""

    def __init__(self):
        self._hits = defaultdict(deque)
        self._lock = threading.Lock()

    def allow(self, key, limit, window_seconds):
        now = time.time()
        with self._lock:
            hits = self._hits[key]
            while hits and hits[0] <= now - window_seconds:
                hits.popleft()
            if len(hits) >= limit:
                return False
            hits.append(now)
            return True


class SessionStore:
    """Keeps admin login tokens in memory. Restarting the server logs everyone out."""

    def __init__(self):
        self._expires = {}
        self._lock = threading.Lock()

    def create(self):
        token = secrets.token_urlsafe(32)
        with self._lock:
            now = time.time()
            self._expires = {t: e for t, e in self._expires.items() if e > now}   # drop expired tokens
            self._expires[token] = now + config.SESSION_HOURS * 3600
        return token

    def is_valid(self, token):
        with self._lock:
            return self._expires.get(token, 0) > time.time()


def detect_image_type(data):
    """Identify a photo by its first bytes (never trust the file name or declared type)."""
    if data.startswith(b"\xff\xd8\xff"):
        return "jpg"
    if data.startswith(b"\x89PNG\r\n\x1a\n"):
        return "png"
    if data[:4] == b"RIFF" and data[8:12] == b"WEBP":
        return "webp"
    return None


CONTENT_SECURITY_POLICY = "; ".join([
    "default-src 'self'",
    "script-src 'self'",
    "style-src 'self' https://fonts.googleapis.com",
    "font-src https://fonts.gstatic.com",
    "img-src 'self' data:",
    "connect-src 'self'",
    "object-src 'none'",
    "base-uri 'self'",
    "form-action 'self'",
    "frame-ancestors 'none'",
])


def security_headers():
    """Headers added to every response."""
    headers = {
        "Content-Security-Policy": CONTENT_SECURITY_POLICY,
        "X-Content-Type-Options": "nosniff",
        "X-Frame-Options": "DENY",
        "Referrer-Policy": "strict-origin-when-cross-origin",
        "Permissions-Policy": "camera=(), microphone=(), geolocation=()",
    }
    if config.IS_PRODUCTION:
        headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
    return headers
