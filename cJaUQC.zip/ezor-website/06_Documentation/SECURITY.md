# Security

## Built in
- **Passwords** are stored as salted PBKDF2-SHA256 hashes. The admin password lives only in `.env`.
- **The server refuses to start** without a strong admin password.
- **Prices and totals** are calculated on the server; the browser cannot change them.
- **SQL injection:** every query uses parameters.
- **Cross-site scripting:** all text is escaped before it is shown, and a strict
  Content-Security-Policy blocks scripts and styles from other sources (fonts excepted).
- **Photos** are checked by their real file signature (JPEG, PNG, WebP), limited to 2 MB, and
  saved under random names.
- **Rate limits** per visitor: 5 logins / 15 min, 15 orders / hour, 5 reviews / hour.
- **Admin logins** expire after 4 hours; the token is kept only for the browser tab.
- **File serving** blocks folder traversal and hidden files (`.env`, `.git`).
- **Headers:** CSP, X-Frame-Options, nosniff, Referrer-Policy, Permissions-Policy, and HSTS in production.
- **Secrets and live data** are excluded from GitHub by `.gitignore`.

## Before going live
- [ ] `APP_ENV=production` and a long unique `ADMIN_PASSWORD` in `.env`
- [ ] Site served over **HTTPS**
- [ ] `.env` is not in the repository (`git status` should not list it)
- [ ] Daily backup of `05_Database/data/`
- [ ] Sample data switched off (`LOAD_SAMPLE_DATA=false`) and real products added

## Known limits
- Rate limits and admin logins are kept in memory and reset when the server restarts.
- One admin account only; no email alerts for new orders yet.
- Customer details in orders are personal data. Keep backups private.
- If a password was ever shared or committed, change it and restart the server.
