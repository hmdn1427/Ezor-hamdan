# Deployment

The site is one Python process plus a database file, so it needs a host that can run Python
and **keep files between restarts**.

## Options
- **A small VPS** (DigitalOcean, Hetzner, etc.): simplest and cheapest to control.
- **Render / Railway / Fly.io**: attach a **persistent disk** and point `DATABASE_PATH` and
  `UPLOADS_DIR` at it, otherwise orders and photos disappear on every restart.

## Steps
1. Upload or `git clone` the repository to the server.
2. Create `.env` there with:
   ```
   APP_ENV=production
   ADMIN_PASSWORD=<a long, unique password>
   HOST=0.0.0.0
   LOAD_SAMPLE_DATA=false
   ```
   (and `DATABASE_PATH` / `UPLOADS_DIR` if using a mounted disk).
3. Start with `python3 app.py`. Keep it running with `systemd` or your host's start command.
4. Put it behind **HTTPS** (Caddy, Nginx, Cloudflare, or your host's built-in certificate).
   If the proxy is yours, also set `TRUST_PROXY=true`.
5. Point your domain at the server.

## Backups
Copy the `data/` folder (or your mounted disk) daily. It contains the database and all photos.

## Updating
Pull the new code and restart. Database changes arrive as new files in `05_Database/migrations/`
and are applied automatically.
