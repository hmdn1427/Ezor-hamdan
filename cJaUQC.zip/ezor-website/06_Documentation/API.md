# API reference

All addresses start with `/api`. Requests and answers are JSON. Errors look like `{"error": "message"}`.
Admin requests need the header `Authorization: Bearer <token>`.

| Method | Address | Who | Body | Answer |
|---|---|---|---|---|
| GET | `/site` | public | | `{whatsappNumber, texts}` |
| GET | `/products` | public | | list of products |
| GET | `/reviews` | public | | list of `{name, stars, text}` |
| POST | `/reviews` | public (5/hour) | `{name, stars, text}` | `{ok}` |
| POST | `/orders` | public (15/hour) | `{customer:{name,email,phone,address}, items:[{id,quantity}]}` | `{orderId, total}` |
| POST | `/admin/login` | public (5/15 min) | `{username, password}` | `{token}` |
| GET | `/admin/orders` | admin | | orders with their items |
| PUT | `/admin/orders/<id>` | admin | `{status}` (new, packed, delivered, cancelled) | `{ok}` |
| POST | `/admin/products` | admin | `{name, category, gender, price, note, image}` (`image` is a JPEG/PNG/WebP data URL, optional) | `{id}` |
| DELETE | `/admin/products/<id>` | admin | | `{ok}` |
| PUT | `/admin/whatsapp` | admin | `{number}` | `{whatsappNumber}` |
| PUT | `/admin/texts` | admin | `{key, text}` | `{ok}` |

## Status codes
`200` success, `400` invalid input, `401` not logged in or wrong login, `404` not found,
`413` request too large, `429` too many requests, `500` server error.

## Product fields
`category`: perfume, wallet, belt. `gender`: men, ladies, unisex. `price`: whole rupees.
