# Setup

1. Install **Python 3.9 or newer** (https://www.python.org). Check with `python3 --version`.
2. Copy the settings template and edit it:
   ```bash
   cp .env.example .env
   ```
   Open `.env` and set `ADMIN_PASSWORD` (8+ characters; 12+ in production).
3. Start the site:
   ```bash
   python3 app.py
   ```
4. Open http://127.0.0.1:8000 and the admin page at http://127.0.0.1:8000/#admin.

On Windows use `python app.py` and `copy .env.example .env`.

## Settings (`.env`)
| Name | Meaning |
|---|---|
| `APP_ENV` | `development` or `production` |
| `ADMIN_USERNAME` / `ADMIN_PASSWORD` | Admin login. The password is applied every time the server starts |
| `HOST` / `PORT` | Where the server listens |
| `TRUST_PROXY` | `true` only behind your own proxy, so real visitor IPs are used for rate limits |
| `LOAD_SAMPLE_DATA` | Load sample products on first start |
| `DATABASE_PATH` / `UPLOADS_DIR` | Move the database and photos to another disk |

## Run the tests
```bash
python3 -m unittest discover -s 07_Testing -v
```
